export default function signup() {
  return (
    <div>
      <nav>
        <a href="/">
          1. A természetes személyeknek a személyes adatok kezelése tekintetében
          történő védelméről és az ilyen adatok szabad áramlásáról, valamint a
          95/46/EK irányelv hatályon kívül helyezéséről szóló az európai
          parlament és tanács 2016. április 27-i (EU) 2016/679 RENDELETE (a
          továbbiakban: GDPR), 2. Az információs önrendelkezési jogról és az
          információszabadságról szóló 2011. évi CXII. törvény (a továbbiakban:
          Info.tv.) II. ADATKEZELÉS CÉLJA, JOGALAPJA: Adatkezelés célja:
          Részvétel a TeSzedd! akcióban. Az akcióra jelentkezők kérdéseinek
          megválaszolása, tájékoztatása. Jövőbeni direkt marketing, hasonló célú
          szemléletformáló akciók kapcsán. Kezelt adatok Név, e-mail cím, postai
          cím, telefonszám. 18 év alatti résztvevők esetében törvényes képviselő
          neve Fénykép, hangfelvétel Adatkezelés jogalapja A személyes adatok
          kezelésének jogalapja a GDPR 6. cikk (1) bekezdés a) pontja szerint az
          érintett hozzájárulása. Személyes adatok forrása Az érintett.
          Személyes adatok továbbítása harmadik országba, vagy nemzetközi
          szervezethez A személyes adatokat nem továbbítjuk sem harmadik
          országba, sem nemzetközi szervezethez. Személyes adatok kezelésének
          időtartama A személyes adatokat a hozzájárulás visszavonásáig
          kezeljük. Az érintett a hozzájárulását bármikor korlátozás és indok
          nélkül jogosult visszavonni az info@teszedd.hu címre küldött
          e-maillel. Automatizált döntéshozatal és profilalkotás Egyik sem
          történik az adatkezelés során. III. AZ ÉRINTETT JOGAI AZ
          ADATKEZELÉSHEZ KAPCSOLÓDÓAN Tájékoztatáshoz való jog Az érintettnek
          joga van az adatkezeléssel kapcsolatos tájékoztatáshoz, melyet a jelen
          tájékoztató rendelkezésre bocsátása útján teljesítünk. Hozzájáruláson
          alapuló adatkezelések A hozzájárulás visszavonását követően a
          személyes adatokat véglegesen és visszaállíthatatlanul töröljük. A
          hozzájárulás visszavonása a GDPR alapján a visszavonás előtt a
          hozzájárulás alapján végrehajtott adatkezelés jogszerűségét nem
          érinti. Hozzáférési jog Az érintettet kérelmére bármikor a
          későbbiekben tájékoztatjuk, hogy a személyes adatainak kezelése
          folyamatban van-e és ha igen, akkor a személyes adatokhoz és a
          következő információkhoz hozzáférést biztosítunk: az adatkezelés
          céljai; az érintett személyes adatok kategóriái; azon címzettek vagy
          címzettek kategóriái, akikkel, illetve amelyekkel a személyes adatokat
          közöltük vagy közölni fogjuk. a személyes adatok tárolásának tervezett
          időtartama, vagy ha ez nem lehetséges, ezen időtartam meghatározásának
          szempontjai; tájékoztatjuk továbbá az érintettet azon jogáról, hogy
          kérelmezheti a rá vonatkozó személyes adatok helyesbítését, törlését
          vagy kezelésének korlátozását, és tiltakozhat az ilyen személyes
          adatok kezelése ellen; a valamely felügyeleti hatósághoz címzett
          panasz benyújtásának, illetve bírósági eljárás megindításának joga;
          Személyes adatok helyesbítéséhez való jog Az érintett bármikor
          jogosult arra, hogy kérésére helyesbítsük a rá vonatkozó pontatlan
          személyes adatokat. Figyelembe véve az adatkezelés célját, az érintett
          jogosult arra is, hogy kérje a hiányos személyes adatok – egyebek
          mellett kiegészítő nyilatkozat útján történő – kiegészítését.
          Törléshez való jog Az érintett jogosult arra, hogy kérésére töröljük a
          rá vonatkozó személyes adatokat, ha az alábbi indokok valamelyike
          fennáll: a személyes adatokra már nincs szükség abból a célból,
          amelyből azokat gyűjtöttük vagy más módon kezeltük; hozzájáruláson
          alapuló adatkezelés esetén visszavonja az adatkezelés alapját képező
          hozzájárulását, és az adatkezelésnek nincs más jogalapja; tiltakozik
          az adatkezelés ellen, és nincs elsőbbséget élvező jogszerű ok az
          adatkezelésre, vagy tiltakozik a közvetlen üzletszerzés céljából
          történő adatkezelés ellen; a személyes adatokat jogellenesen kezeltük;
          a személyes adatokat az alkalmazandó uniós vagy tagállami jogban
          előírt jogi kötelezettség teljesítéséhez törölni kell; Az adatok
          törlése végelegesen és visszaállíthatatlanul történik. Törlés esetén
          erről értesítjük azon adatkezelőket is, akiknek az érintett
          hozzájárulásával korábban az adatokat továbbítottuk. Az adatkezelés
          korlátozásához való jog Az érintett jogosult arra, hogy kérésére
          korlátozzuk az adatkezelést, ha az alábbiak valamelyike teljesül:
          vitatja a személyes adatok pontosságát; ez esetben a korlátozás arra
          az időtartamra vonatkozik, amely lehetővé teszi, hogy ellenőrizzük a
          személyes adatok pontosságát; az adatkezelés jogellenes, és ellenzi az
          adatok törlését, ehelyett kéri azok felhasználásának korlátozását; már
          nincs szükségünk a személyes adatokra adatkezelés céljából, de az
          érintett igényli azokat jogi igények előterjesztéséhez,
          érvényesítéséhez vagy védelméhez; vagy az érintett tiltakozott az
          adatkezelés ellen; ez esetben a korlátozás arra az időtartamra
          vonatkozik, amíg megállapításra nem kerül, hogy az adatkezelés iránti
          jogos indokaink elsőbbséget élveznek-e az érintett jogos indokaival
          szemben. Adathordozhatósághoz való jog Az érintett jogosult arra, hogy
          a rá vonatkozó, általa egy adatkezelő rendelkezésére bocsátott
          személyes adatokat tagolt, széles körben használt, géppel olvasható
          formátumban megkapja, továbbá jogosult arra, hogy ezeket az adatokat
          egy másik adatkezelőnek továbbítsa, ha: az adatkezelés a
          hozzájárulásán alapul; és az adatkezelés automatizált módon történik.
          IV. AZ ÉRINTETT JOGAINAK ÉRVÉNYESÍTÉSÉRE SZOLGÁLÓ ELJÁRÁSREND Az
          érintett a fenti jogait elsősorban az info@teszedd.hu e-mail címre
          megküldött elektronikus levelében, vagy az Adatkezelő székhelyére
          (1011 Budapest, Fő utca 44-50.) eljuttatott postai levélben
          gyakorolhatja. A kérelem alapján tett intézkedésekről a beérkezésétől
          számított 30 napon belül tájékoztatjuk. Amennyiben a kérelmet nem áll
          módunkban teljesíteni, úgy 30 napon belül tájékoztatjuk a teljesítése
          megtagadásának okairól és a jogorvoslati jogairól. V. JOGORVOSLATI JOG
          AZ ADATKEZELÉSHEZ KAPCSOLÓDÓAN Amennyiben az érintett úgy ítéli meg,
          hogy a rá vonatkozó személyes adatok kezelése megsérti a GDPR-t, vagy
          az Infotv.-t, jogosult arra, hogy – az egyéb közigazgatási vagy
          bírósági jogorvoslatok sérelme nélkül – panasz tegyen az adatkezelővel
          szemben. A bírósági jogorvoslathoz való jogának érvényesítése
          érdekében az érintett az adatkezelővel szemben bírósághoz fordulhat,
          ha megítélése szerint az adatkezelő, illetve az általa megbízott vagy
          rendelkezése alapján eljáró adatfeldolgozó a személyes adatait a
          személyes adatok kezelésére vonatkozó jogszabályban, vagy az Európai
          Unió kötelező jogi aktusában meghatározott előírások megsértésével
          kezeli. A Nemzeti Adatvédelmi és Információszabadság Hatóságnál (NAIH)
          bejelentéssel az adatkezelővel szemben bárki vizsgálatot
          kezdeményezhet arra hivatkozással, hogy személyes adatok kezelésével
          kapcsolatban jogsérelem következett be, vagy annak közvetlen veszélye
          fennáll, illetve hogy az adatkezeléshez kapcsolódó jogainak
          érvényesítését korlátoztuk, vagy ezen jogainak érvényesítésére
          irányuló kérelmét elutasítottuk. A bejelentést az alábbi elérhetőségek
          valamelyikén lehet megtenni: Nemzeti Adatvédelmi és
          Információszabadság Hatóság (NAIH) Posta cím: 1530 Budapest, Pf.: 5.
          Cím: 1125 Budapest, Szilágyi Erzsébet fasor 22/c Telefon: +36 (1)
          391-1400 Fax: +36 (1) 391-1410 E-mail: ugyfelszolgalat@naih.hu URL:
          http://naih.hu COOKIE („SÜTI”) TÁJÉKOZTATÓ 1. Adatkezelő adatai:
          Adatkezelő megnevezése: Innovációs és Technológiai Minisztérium PIR
          azonosító: 764410 Adatkezelő székhelye: 1011 Budapest, Fő utca 44-50.
          Adatkezelő postai címe: 1440 Budapest Pf. 1. Adatkezelő elektronikus
          címe: ugyfelszolgalat@itm.gov.hu Adatvédelmi tisztviselőjének neve és
          elérhetősége: dr. Dakos Zsuzsannapostai címe: 1011 Budapest, Fő utca
          44-50.e-mail címe: adatvedelmi.tisztviselo@itm.gov.hu 2. Cookie
          („süti”) tájékoztató hatálya: Jelen tájékoztató a www.szelektalok.hu
          weboldalra vonatkozik. 3. Cookie („süti”) fogalma, célja és jellemzői:
          Az oldal „sütiket” használ az oldal megfelelő működéséhez, valamint
          annak érdekében, hogy azonosítsa a felhasználót, azaz megkülönböztesse
          a felhasználókat egymástól, s ezzel a felhasználók releváns és
          személyre szabott tartalmat kapjanak. A „sütik” kényelmesebbé teszik a
          böngészést, értve ez alatt az online adatbiztonsággal kapcsolatos
          igényeket. A „sütik” a webszerver és a felhasználó böngészője közötti
          információcsere eszközei. A „sütik” olyan betűkből és számokból álló
          szöveges fájlok, amelyek – a felhasználó hozzájárulásának függvényében
          – információt tárolnak a felhasználó webes böngészőjében abból a
          célból, hogy még hatékonyabbá tegyék a felhasználói élményt. Ezek az
          adatfájlok nem futtathatók, nem tartalmaznak kémprogramokat és
          vírusokat, továbbá nem férhetnek hozzá a felhasználók
          merevlemez-tartalmához. Amennyiben a „sütik” engedélyezése
          megtörténik, úgy a weboldal rögzíti a felhasználó látogatásával
          kapcsolatos információkat. A legtöbb „süti” nem tartalmaz személyes
          információkat, segítségével nem azonosíthatók a felhasználók. A tárolt
          adatok a kényelmesebb böngészésért szükségesek, tárolásuk olyan módon
          történik, hogy jogosulatlan személy nem férhet hozzájuk. Kiemelendő
          azonban, hogy a „sütik” tárolása csak és kizárólag abban az esetben
          lehetséges, ha az adott weboldal működéséhez arra feltétlenül szükség
          van. 4. Cookie („süti”) típusai Az ITM az alábbi „süti”-fajtákat
          használja: Statisztikai célú „sütik” A statisztikai célú „sütik”
          információt biztosítanak a honlap megfelelő fejlesztéséhez: az adatok
          névtelen formában való gyűjtésén és jelentésén keresztül a
          statisztikai „sütik” segítenek a weboldal tulajdonosának abban, hogy
          megértse, hogyan lépnek interakcióba a látogatók a weboldallal. Ezek a
          „sütik” a felhasználók és munkameneteik adatai, böngésző beállításai
          alapján felhasználóhoz nem köthető általános használati adatokat
          biztosítanak a weboldal tulajdonosának. Ilyen lehet például az, hogy
          milyen böngészőből keresik fel jellemzően a honlapot és így melyik
          böngészőverziókra célszerű azt optimalizálni. Ezen felül e „sütik”
          használatával információk gyűjthetők, hogy a felhasználó a weboldal
          mely részére kattintott, hány oldalt keresett fel, milyen hosszú volt
          az egyes munkamenetek megtekintési ideje, melyek voltak az esetleges
          hibaüzenetek – mindezt a weboldal fejlesztésének, valamint a
          felhasználók számára biztosított élmények javításának céljával. Ezek
          nem gyűjtenek a felhasználót azonosítani képes információkat, az
          adatokat összesítve és névtelenül tárolják. 5. A böngésző Cookie
          („sütik”) beállításainak ellenőrzése és a Cookies („sütik”) letiltása
          A legtöbb böngésző alapbeállításként engedi a „sütik” használatát.
          Amennyiben a felhasználó ezt mégsem kívánja, illetve nem fogadja el
          ezen „sütik” alkalmazását, úgy módosíthatja és kikapcsolhatja ezeket
          böngészője beállításával, illetve a korábbi hozzájárulása is
          módosítható vagy visszavonható. A beállítási lehetőségek általában a
          böngésző „Opciók” vagy „Beállítások” menüpontjában találhatók.
          Mindegyik böngésző különböző, így a megfelelő beállításokhoz kérjük
          használja böngészője “Segítség” menüjét. Ha a felhasználó a
          böngészőjében az összes „sütit” letiltja (ideértve a feltétlenül
          szükséges „sütiket”), akkor előfordulhat, hogy a weboldal egy részét
          vagy egészét nem fogja tudni elérni. A „sütikről” és azok letiltásáról
          az alábbi oldalon található részletes információ:
          www.allaboutcookies.org. A letiltott vagy korlátozott „sütik” azonban
          nem jelentik azt, hogy a felhasználóknak nem jelennek meg hirdetések,
          csupán a megjelenő hirdetések és tartalmak nem „személyre szabottak”,
          azaz nem igazodnak a felhasználó igényeihez és érdeklődési köréhez. 6.
          Adatvédelmi tájékoztatás Az oldalon alkalmazott sütik esetében az
          adatkezelés jogalapja a GDPR 6. cikk e) pontja, az adatkezelés
          közérdekű vagy az adatkezelőre ruházott közhatalmi jogosítvány
          gyakorlásának keretében végzett feladat végrehajtásához szükséges,
          valamint a) pontja, az érintett hozzájárulását adta személyes
          adatainak egy vagy több konkrét célból történő kezeléséhez. 7.
          Adatkezelés időtartama Az adatok kezelésének és tárolásának időtartama
          26 hónap. 8. Adatkezeléssel kapcsolatos érintetti jogok gyakorlása: Az
          érintett a személyes adatai kezelésével kapcsolatban bejelentést tehet
          az adatkezelő adatvédelmi tisztviselőjénél, a fent megadott
          elérhetőségein. Az érintett továbbá panaszt nyújthat be a Nemzeti
          Adatvédelmi és Információszabadság Hatóságnál (cím:1055 Budapest, Falk
          Miksa utca 9-11., postacím: 1530 Budapest, Pf.: 5, e-mail cím:
          ugyfelszolgalat@naih.hu) mint felügyeleti hatóságnál, ha megítélése
          szerint a rá vonatkozó személyes adatok kezelése sérti a GDPR
          rendelkezéseit. Az érintett bírósághoz fordulhat, ha megítélése
          szerint a személyes adatainak nem megfelelő kezelése következtében
          megsértették a GDPR szerinti jogait.
        </a>
      </nav>
    </div>
  );
}
