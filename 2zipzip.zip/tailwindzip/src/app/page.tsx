"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function Home() {
  const [currentBgIndex, setCurrentBgIndex] = useState(0);
  const backgroundImages = ["/images/este.jpg", "/images/lambo.jpg"];
  const changeBackground = () => {
    setCurrentBgIndex((prevIndex) => (prevIndex + 1) % backgroundImages.length);
  };
  const teloBackground = ["/images/estetelo.jpg", "/images/lambo2.jpg"];
  const changeTeloBackground = () => {
    setCurrentBgIndex((prevIndex) => (prevIndex + 1) % teloBackground.length);
  };
  const goToConfiguration = () => {
    window.location.href =
      "https://configurator.lamborghini.com/configurator/configuration/ePl9IIpV5dNLbsMgEAbgq-QCVk0ejbPkYQyOsTG2Q8VdevfCDKSVEnVRdVGp0Sw-MQ7m8fthw4bdqj0516dypZ_bT5kiVTCH-kpe6tJ_ciKSHHdnUqeDlafXXfpd0ulKvumxMkqMtLKirxYl5rXydRt7nSVHC9nsLB9jgUQfC9TZWCDVxEJdYiXFKfIsnhAPye_8vvaQ3c7fSKykoLZYUT110iiEWxCBhoAQBW2Byg-HaxkxPYwwbrHFAkVwOmZMBY7hv7iz-C5Bh4INnxHTVOAQkvEMfodeMlxBPFDASnE90usZNijLdmRgBQrRqbxUJYYCh62BeRwZ-IgjcFsJji_YWtiKI0ubZ15anVvpQgGDzK1py1h5wRsu3nPcqaHMESuTmLC9SjdluGV6A7V6OJsDapsbDTJ6dOn7NQO387wHadp0R9CVnusVtLSNg5ktXy-XISlIU6_tNx_t76X3WVL_Vz7_SCx_lsavGXySvHvKHrP1_gEKjFFf/exterior?lang=eng&country=hu";
  };
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const toggleLanguageModal = () => {
    setIsLanguageModalOpen(!isLanguageModalOpen);
  };
  return (
    <div>
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
      />
      <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/css/flag-icons.min.css"
      />
      <div className="h-screen w-full relative hidden md:block">
        <Image
          src={backgroundImages[currentBgIndex]}
          alt="lambo"
          layout="fill"
          objectFit="cover"
          quality={100}
        />
      </div>
      <div className="md:hidden h-screen w-full relative ">
        <Image
          src={teloBackground[currentBgIndex]}
          alt="lambo"
          layout="fill"
          objectFit="cover"
          quality={100}
        />
      </div>
      <nav className="bg-neutral-900 w-62 h-screen fixed bottom-0 hidden md:block">
        <div className="flex items-center gap-2">
          <a href="https://www.lamborghini.com" className=" ml-2 mt-2">
            <Image
              src="/images/logo_header_01.svg"
              alt="logo"
              width={55}
              height={55}
            />
          </a>

          <button
            type="button"
            className="text-white font-bold mt-2 ml-4 flex items-center "
          >
            Revuelto
            <svg
              className="-mr-1 size-5 text-gray-400  "
              viewBox="0 0 20 20"
              fill="currentColor"
              aria-hidden="true"
              data-slot="icon"
            >
              <path
                fill-rule="evenodd"
                d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z"
                clip-rule="evenodd"
              />
            </svg>
          </button>
        </div>
        <div className="  w-full mt-4 ">
          <h1 className="absolute pl-4 pt-4 text-l font-bold">Revuelto</h1>

          <Image
            src="/images/alul.png"
            alt="lambo"
            className="bg-white "
            width={300}
            height={100}
            quality={100}
          />
        </div>
      </nav>
      <div className=" bg-transparent fixed left-60 bottom-185 hidden md:flex ">
        <div className="flex items-center gap-2 ">
          <h1 className="text-white text-7xl font-bold mt-30 ml-9  ">
            Revuelto
          </h1>
        </div>
        <div className="flex-col fixed top-10 right-12 hidden md:flex">
          <button
            className="bg-neutral-900  border-b border-neutral-700 rounded-t-lg items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black"
            onClick={toggleLanguageModal}
          >
            <i className="fa-solid text-white  fa-globe"></i>
          </button>
          <button
            className="bg-neutral-900  items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black"
            onClick={() => {}}
          >
            <i className="fa-solid  text-white hover:text-black fa-magnifying-glass"></i>
          </button>
          <button
            className="bg-neutral-900 rounded-b-lg border-t border-neutral-700 items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black"
            onClick={changeBackground}
          >
            <i className="fa-solid  text-white fa-moon"></i>
          </button>
        </div>
        <div className="flex flex-row  fixed bottom-12 pl-12 pb-12 gap-6 ">
          <h3 className="text-white text-md font-italic">
            POWER
            <p className="text-white text-4xl font-italic border-r border-white pr-4">
              1015 CV
            </p>
          </h3>
          <h3 className="text-white text-md font-italic">
            MAX SPEED
            <p className="text-white text-4xl font-italic border-r-2 border-white pr-4">
              350 km/h
            </p>
          </h3>
          <h3 className="text-white text-md font-italic">
            0-100 km/h
            <p className="text-white text-4xl font-italic ">2.5 s</p>
          </h3>

          <div className="bg-white rounded-xl items-center ml-auto flex fixed  bottom-25 right-18">
            <button
              className="text-black text-md font-italic py-3 px-12 font-bold hover:bg-gray-800 hover:text-white hover:rounded-xl"
              onClick={goToConfiguration}
            >
              START CONFIGURATION
            </button>
          </div>
        </div>
      </div>

      <footer className="bg-neutral-900 w-full flex flex-col sm:flex-row px-4 py-3 bottom-0 fixed border-t border-neutral-700 items-center">
        <p className="text-white text-xs max-w-full overflow-x-auto pb-2 sm:pb-0 sm:pr-4">
          Fuel consumption combined: 11,86 l/100km; Power consumption combined:
          10,1 kWh/100 Km; CO₂ emissions combined: 276 g/km; CO₂ efficiency
          class combined: G
        </p>

        <a
          href="/adatved"
          className="text-yellow-500 font-bold text-xs whitespace-nowrap sm:ml-auto"
        >
          Privacy & Legal
        </a>
      </footer>
      <div
        tabIndex={-1}
        aria-hidden={!isLanguageModalOpen}
        className={`${isLanguageModalOpen ? "flex" : "hidden"} overflow-y-auto overflow-x-hidden fixed inset-0 z-50 items-center justify-center  bg-opacity-120`}
      >
        <div className="bg-neutral-900 rounded-lg p-6 shadow-xl border border-neutral-700 relative top-1/2 -translate-y-1/2 mb-auto  ">
          <button
            className="text-white mt-1 absolute top-3  right-2  hover:text-black bg-neutral-700 w-8 h-8 rounded-lg cursor-pointer"
            onClick={toggleLanguageModal}
          >
            <i className="fa-solid fa-times  "></i>
          </button>
          <h1 className="text-white text-xl font-bold">Change Language</h1>
          <h1 className="text-white text-sm font-italic">
            Select the language for the configurator
          </h1>
          <ul className="flex flex-col " aria-label="scrollable content">
            <li className="text-white py-2 border-b border-neutral-700 flex flex-row text-lg ">
              <span className="fi fi-gb "></span>
              <div className="ml-2">English</div>
              <input
                type="radio"
                id="option5"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option5"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700 flex flex-row text-lg ">
              <span className="fi fi-hu"></span>
              <div className="ml-2">Hungarian</div>
              <input
                type="radio"
                id="option6"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option6"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
              <span className="fi fi-de"></span>
              <div className="ml-2">German</div>
              <input
                type="radio"
                id="option7"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option7"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
              <span className="fi fi-fr"></span>
              <div className="ml-2">French</div>
              <input
                type="radio"
                id="option8"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option8"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
              <span className="fi fi-it"></span>
              <div className="ml-2">Italian</div>
              <input
                type="radio"
                id="option3"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option3"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
              <span className="fi fi-es"></span>
              <div className="ml-2">Spanish</div>
              <input
                type="radio"
                id="option2"
                name="option"
                className=" peer hidden"
              />
              <label
                htmlFor="option2"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
            <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
              <span className="fi fi-cn"></span>
              <div className="ml-2">Chinese</div>
              <input
                type="radio"
                id="option1"
                name="option"
                className=" hidden peer"
              />
              <label
                htmlFor="option1"
                className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
              ></label>
            </li>
          </ul>
        </div>
      </div>
      <nav className="md:hidden bg-neutral-900 fixed top-0 w-full flex items-center ">
        <a href="https://www.lamborghini.com" className=" ml-2 ">
          <Image
            src="/images/logo_header_01.svg"
            alt="logo"
            className="p-1"
            width={55}
            height={55}
          />
        </a>
        <button
          type="button"
          className="text-white font-bold mx-2 ml-4 flex items-center "
        >
          Revuelto
          <svg
            className="size-5 text-gray-400 "
            viewBox="0 0 20 20"
            fill="currentColor"
            aria-hidden="true"
            data-slot="icon"
          >
            <path
              fill-rule="evenodd"
              d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z"
              clip-rule="evenodd"
            />
          </svg>
        </button>
        <button
          className="bg-neutral-900  items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black ml-auto border-l border-neutral-700"
          onClick={() => {}}
        >
          <i className="fa-solid  text-white hover:text-black fa-magnifying-glass"></i>
        </button>
        <button
          className="bg-neutral-900 items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black  "
          onClick={toggleLanguageModal}
        >
          <i className="fa-solid text-white  fa-globe"></i>
        </button>

        <div
          tabIndex={-1}
          aria-hidden={!isLanguageModalOpen}
          className={`${isLanguageModalOpen ? "flex" : "hidden"} overflow-y-auto overflow-x-hidden fixed inset-0 z-50 items-center justify-center  bg-opacity-120`}
        >
          <div className="bg-neutral-900 rounded-lg p-6 shadow-xl border border-neutral-700 relative top-1/2 -translate-y-1/2 mb-auto  ">
            <button
              className="text-white mt-1 absolute top-3  right-2  hover:text-black bg-neutral-700 w-8 h-8 rounded-lg cursor-pointer"
              onClick={toggleLanguageModal}
            >
              <i className="fa-solid fa-times  "></i>
            </button>
            <h1 className="text-white text-xl font-bold">Change Language</h1>
            <h1 className="text-white text-sm font-italic">
              Select the language for the configurator
            </h1>
            <ul className="flex flex-col " aria-label="scrollable content">
              <li className="text-white py-2 border-b border-neutral-700 flex flex-row text-lg ">
                <span className="fi fi-gb "></span>
                <div className="ml-2">English</div>
                <input
                  type="radio"
                  id="option5"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option5"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700 flex flex-row text-lg ">
                <span className="fi fi-hu"></span>
                <div className="ml-2">Hungarian</div>
                <input
                  type="radio"
                  id="option6"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option6"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
                <span className="fi fi-de"></span>
                <div className="ml-2">German</div>
                <input
                  type="radio"
                  id="option7"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option7"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
                <span className="fi fi-fr"></span>
                <div className="ml-2">French</div>
                <input
                  type="radio"
                  id="option8"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option8"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
                <span className="fi fi-it"></span>
                <div className="ml-2">Italian</div>
                <input
                  type="radio"
                  id="option3"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option3"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
                <span className="fi fi-es"></span>
                <div className="ml-2">Spanish</div>
                <input
                  type="radio"
                  id="option2"
                  name="option"
                  className=" peer hidden"
                />
                <label
                  htmlFor="option2"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
              <li className="text-white py-2 border-b border-neutral-700  flex flex-row text-lg ">
                <span className="fi fi-cn"></span>
                <div className="ml-2">Chinese</div>
                <input
                  type="radio"
                  id="option1"
                  name="option"
                  className=" hidden peer"
                />
                <label
                  htmlFor="option1"
                  className="  w-5 h-5 border-2 border-gray-400 rounded-full flex cursor-pointer items-center justify-center peer-checked:border-black peer-focus:outline-black peer-checked:bg-white ml-auto mt-1"
                ></label>
              </li>
            </ul>
          </div>
        </div>
        <button
          className="bg-neutral-900 rounded-lg border-t border-neutral-700 items-center  text-center py-3 w-12 hover:bg-slate-500 hover:text-black bottom-35 right-5 fixed "
          onClick={changeBackground}
        >
          <i className="fa-solid  text-white fa-moon"></i>
        </button>
      </nav>
      <div className="bg-white  items-center  flex fixed  bottom-20 md:hidden  w-full">
        <button
          className="text-black text-md font-italic py-3 px-12 font-bold hover:bg-gray-800 hover:text-white  w-full"
          onClick={goToConfiguration}
        >
          START CONFIGURATION
        </button>
      </div>
    </div>
  );
}
